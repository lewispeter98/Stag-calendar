# 🍺 Stag Do App — Setup Guide
## (Written for doing this on your phone)

---

## STEP 1 — Create your Supabase database (~10 mins)

1. Go to **supabase.com** → Sign up (free)
2. Click **New Project** → give it a name like `stag-do` → set a database password → hit Create
3. Wait ~2 mins for it to provision
4. In the left sidebar, click **SQL Editor**
5. Paste this SQL and hit **Run**:

```sql
create table votes (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  date text not null,
  status text not null,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now(),
  unique(name, date)
);

alter table votes enable row level security;

create policy "Allow all reads" on votes for select using (true);
create policy "Allow all inserts" on votes for insert with check (true);
create policy "Allow all updates" on votes for update using (true);
create policy "Allow all deletes" on votes for delete using (true);
```

6. Go to **Project Settings** (cog icon) → **API**
7. Copy and save these two values somewhere (you'll need them in Step 3):
   - **Project URL** (looks like `https://xxxx.supabase.co`)
   - **anon public** key (long string under "Project API keys")

---

## STEP 2 — Put the code on GitHub (~10 mins)

1. Go to **github.com** → Sign up or log in (free)
2. Click **+** → **New repository**
   - Name it `stag-do-planner`
   - Set to **Private**
   - Tick "Add a README file"
   - Hit **Create repository**
3. You now need to upload the app files. On mobile the easiest way is:
   - In your repo, click **Add file** → **Upload files**
   - Upload all the files from the zip I've provided, maintaining the folder structure
   - Commit to main

> 💡 **Tip:** If this feels fiddly on mobile, the GitHub mobile app (free download) makes file uploads easier.

---

## STEP 3 — Deploy on Vercel (~5 mins)

1. Go to **vercel.com** → Sign up with your GitHub account
2. Click **Add New** → **Project**
3. Find and select your `stag-do-planner` repo → click **Import**
4. Before hitting Deploy, click **Environment Variables** and add these two:

| Name | Value |
|------|-------|
| `NEXT_PUBLIC_SUPABASE_URL` | your Project URL from Step 1 |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | your anon public key from Step 1 |

5. Hit **Deploy** — Vercel builds it automatically (~2 mins)
6. You'll get a URL like `stag-do-planner.vercel.app` — that's your app! 🎉

---

## STEP 4 — Share it

Send the Vercel URL to all the lads. No accounts, no downloads — just open the link, pick their name, and fill in their dates.

---

## How it works

- Everyone picks their name on first visit — saved to their phone so they're auto-recognised next time
- Tap dates to cycle: **Available → Unavailable → Maybe**
- All votes save instantly to Supabase
- The **Results** tab ranks weekends by votes — your (Lewis E) unavailable dates are hidden from results automatically
- Anyone who changes phone or clears their browser just picks their name again — their votes are safe in the database

---

## Troubleshooting

**"supabaseUrl is required"** → Check your environment variables in Vercel are named exactly right (case sensitive)

**Votes not saving** → Check the SQL policies ran correctly in Supabase — go to Authentication → Policies and confirm the `votes` table has 4 policies

**App won't build** → Check the Vercel deployment logs — usually a missing env variable
