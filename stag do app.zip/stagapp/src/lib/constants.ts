export const GROOM = 'Lewis'
export const ORGANISER = 'Lewis E'

export const NAMES: string[] = [
  'Adam M',
  'Adam R',
  'Andy E',
  'Andy M',
  'Ben T',
  'Cam F',
  'Cam L',
  'Dave S',
  'David M',
  'Elliot E',
  'Jim L',
  'Joe K',
  'John M',
  'Lewis E',
  'Michael H',
  'Tom M',
  'Tony H',
  'Will M',
  'Zach S',
]

// Generate every Fri/Sat/Sun from 11 Jul → 17 Aug 2025
function generateDates(): string[] {
  const dates: string[] = []
  const start = new Date('2025-07-11') // first Friday
  const end = new Date('2025-08-17')   // last Sunday
  const cur = new Date(start)
  while (cur <= end) {
    const day = cur.getDay()
    if (day === 5 || day === 6 || day === 0) {
      dates.push(cur.toISOString().split('T')[0])
    }
    cur.setDate(cur.getDate() + 1)
  }
  return dates
}

export const DATES: string[] = generateDates()

export type Status = 'available' | 'unavailable' | 'maybe' | null
